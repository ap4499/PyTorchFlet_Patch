from torch.ao.nn.intrinsic.quantized import BNReLU2d
from torch.ao.nn.intrinsic.quantized import BNReLU3d

__all__ = [
    'BNReLU2d',
    'BNReLU3d',
]
