from torch.ao.nn.intrinsic.quantized.dynamic import LinearReLU

__all__ = [
    'LinearReLU',
]
